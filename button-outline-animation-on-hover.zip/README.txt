A Pen created at CodePen.io. You can find this one at http://codepen.io/egrucza/pen/gbXBQQ.

 Inspired by the Learn More buttons found here: http://kenjiendo.com/news/